# Auto High Quality Audio Selector (Kodi 21 Omega)
import xbmc
import xbmcaddon
import time

ADDON = xbmcaddon.Addon()
MONITOR = xbmc.Monitor()

AUDIO_PRIORITY = [
    "truehd",
    "atmos",
    "dts:x",
    "dtsx",
    "dts-hd",
    "dtshd",
    "eac3",
    "ddp",
    "ac3",
    "dts",
    "aac",
    "mp3"
]

def log(msg):
    xbmc.log(f"[AutoHQAudio] {msg}", xbmc.LOGINFO)

def choose_best_audio():
    player = xbmc.Player()
    try:
        streams = player.getAvailableAudioStreams()
    except:
        return

    best_index = None
    best_score = 999

    for i, s in enumerate(streams):
        codec = s.get("codec", "").lower()

        for rank, keyword in enumerate(AUDIO_PRIORITY):
            if keyword in codec:
                if rank < best_score:
                    best_score = rank
                    best_index = i
                break

    if best_index is not None:
        log(f"Switching to audio track #{best_index}")
        player.setAudioStream(best_index)

def main():
    log("Service started.")
    while not MONITOR.abortRequested():
        if xbmc.Player().isPlayingVideo():
            time.sleep(1)  # đợi addon video load metadata
            choose_best_audio()
            time.sleep(2)
        time.sleep(0.5)

if __name__ == '__main__':
    main()
